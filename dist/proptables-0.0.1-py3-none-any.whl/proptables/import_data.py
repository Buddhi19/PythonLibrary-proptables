import pandas as pd
from pathlib import Path

data_path = Path(Path.cwd(), 'proptables', 'R134a_Super.csv')

print(data_path)