[![PyPI version](https://badge.fury.io/py/R134aPT.svg)](https://badge.fury.io/py/R134aPT)
[![pypi supported versions](https://img.shields.io/pypi/pyversions/R134aPTs.svg)](https://pypi.python.org/pypi/R134aPT)
# PropertyTables_Python
This is a digital Property Table of R134a
You can add some data and obtain relavant data for R134a

# To Install

    pip install PropTables

## Sample Calculation (Before Packaging)

![Screenshot 2023-06-05 001930](https://github.com/Buddhi19/PropertyTables_Python/assets/119914594/2ae5d53a-13ea-41e0-a487-507a3bc1bace)

## Required Data Can be Obtained

![Screenshot 2023-06-01 180639](https://github.com/Buddhi19/PropertyTables_Python/assets/119914594/435f290a-3e75-4ebf-b81a-007314f0691d)
