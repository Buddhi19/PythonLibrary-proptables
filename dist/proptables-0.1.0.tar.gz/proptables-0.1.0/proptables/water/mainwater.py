

def water(Temperature=None,Pressure=None,Enthalpy=None,Entropy=None,specificvolume=None,Superheated=None,Compressed=None):
    if Temperature:
        pass