from proptables.R134a.__init__ import R134a
from proptables.water.__init__ import water